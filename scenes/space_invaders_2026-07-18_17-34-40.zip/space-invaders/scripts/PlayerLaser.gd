extends Area2D
class_name Laser
@export var speed = 600
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	print("layer",String.num_uint64(collision_layer, 2))
	print("mask",String.num_uint64(collision_mask, 2))

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.y -= delta * speed

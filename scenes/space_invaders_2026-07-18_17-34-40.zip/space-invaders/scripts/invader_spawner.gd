extends Node2D
class_name InvaderSpawner
const ROWS = 5
const COLS = 10
const HORIZSPACE = 32
const VERTSPACE = 32
const STARTY = 50
const START_X = 200
const INVADERPOSX = 10
const INVADERPOSY = 20
var movedirection = 1
var invader = preload("uid://dglr23iebb666")
var invaderLaser = preload("res://scenes/enemy_laser.tscn")
@onready var timer: Timer = $Timer
@onready var shoot_timer: Timer = $ShootTimer
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	shoot_timer.timeout.connect(shootLaser)
	timer.timeout.connect(moveInvaders)
	for row in ROWS:
		# var rowwidth = (COLS * 24 * 1.5) + ((COLS - 1) * HORIZSPACE)
		var startx = START_X #+ (position.x-rowwidth)/2
		for col in COLS:
			var x = startx + (col * 24 * 1.5) + (col * HORIZSPACE)
			var y = STARTY + (row * 24 ) + (row * VERTSPACE)
			var type = 10
			if row == 0:
				type = 50
			elif row <3:
				type = 20
			spawnInvader(Vector2(x, y), type)

func spawnInvader(pos:Vector2, type:int):
	print("creating invader")
	var inv = invader.instantiate() as Invader
	inv.invadertype = type
	inv.global_position = pos
	add_child(inv)

func moveInvaders():
	position.x += INVADERPOSX * movedirection
	

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_left_wall_area_entered(area: Area2D) -> void:
	if area is Invader:
		if movedirection == -1:
			movedirection = 1
			position.y += INVADERPOSY

func _on_right_wall_area_entered(area: Area2D) -> void:
	if area is Invader:
		if movedirection == 1:
			movedirection = -1
			position.y += INVADERPOSY

func shootLaser():
	var invaderGroup = get_children().filter(func(c): return c is Invader)
	var shootInvader = invaderGroup.pick_random()
	var shot = invaderLaser.instantiate() as enemyLaser
	shot.global_position = shootInvader.global_position
	get_tree().root.add_child(shot)

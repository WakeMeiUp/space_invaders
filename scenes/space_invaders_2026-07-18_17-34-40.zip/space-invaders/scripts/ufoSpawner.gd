extends Node2D
@export var UFOScene:PackedScene
@onready var spawn_timer: Timer = $SpawnTimer
var next_seqno = 1

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	spawn_timer.timeout.connect(spawnUFO)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func spawnUFO():
	var UFO = UFOScene.instantiate()
	UFO.seqno = next_seqno
	next_seqno += 1
	UFO.global_position = global_position
	#get_tree().root.add_child(UFO)
	add_child(UFO)
